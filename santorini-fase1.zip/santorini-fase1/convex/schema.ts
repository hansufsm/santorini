import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

export default defineSchema({
  // Tabela de transações financeiras (extratos InfinitePay)
  transactions: defineTable({
    date: v.string(),           // YYYY-MM-DD
    time: v.string(),           // HH:MM:SS
    type: v.string(),           // Pix, Boleto, Depósito de vendas, etc.
    name: v.string(),           // Nome limpo (sem prefixo "Pix ")
    detail: v.string(),         // "Recebido" ou "Enviado"
    value: v.number(),          // Positivo = entrada, negativo = saída
    originalValue: v.string(),  // String original do CSV
    transactionKey: v.string(), // Chave de deduplicação
    importedAt: v.number(),     // Timestamp da importação
  })
    .index("by_date", ["date"])
    .index("by_key", ["transactionKey"])
    .index("by_detail", ["detail"])
    .index("by_date_detail", ["date", "detail"]),

  // Tabela de associados
  associates: defineTable({
    name: v.string(),           // Nome completo
    unit: v.string(),           // Lote/unidade (ex: "028")
    cpf: v.optional(v.string()), // CPF completo (armazenado com segurança)
    cpfPrefix: v.optional(v.string()), // Primeiros 4 dígitos para busca
    phone: v.optional(v.string()),
    email: v.optional(v.string()),
    status: v.union(
      v.literal("ativo"),
      v.literal("inativo"),
      v.literal("inadimplente")
    ),
    joinedAt: v.optional(v.string()), // YYYY-MM-DD
    notes: v.optional(v.string()),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_status", ["status"])
    .index("by_unit", ["unit"])
    .index("by_name", ["name"]),
});
