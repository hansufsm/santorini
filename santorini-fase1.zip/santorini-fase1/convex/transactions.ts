import { mutation, query } from "./_generated/server";
import { v } from "convex/values";

// ─── MUTATIONS ────────────────────────────────────────────────────────────────

/**
 * Importa um lote de transações do CSV, deduplicando por transactionKey.
 * Retorna quantas foram inseridas e quantas já existiam.
 */
export const importTransactions = mutation({
  args: {
    transactions: v.array(v.object({
      date: v.string(),
      time: v.string(),
      type: v.string(),
      name: v.string(),
      detail: v.string(),
      value: v.number(),
      originalValue: v.string(),
      transactionKey: v.string(),
    })),
  },
  handler: async (ctx, { transactions }) => {
    let inserted = 0;
    let skipped = 0;
    const importedAt = Date.now();

    for (const tx of transactions) {
      // Verifica se já existe pela chave de deduplicação
      const existing = await ctx.db
        .query("transactions")
        .withIndex("by_key", (q) => q.eq("transactionKey", tx.transactionKey))
        .first();

      if (existing) {
        skipped++;
        continue;
      }

      await ctx.db.insert("transactions", {
        ...tx,
        importedAt,
      });
      inserted++;
    }

    return { inserted, skipped, total: transactions.length };
  },
});

// ─── QUERIES ─────────────────────────────────────────────────────────────────

/**
 * Retorna todas as transações ordenadas por data decrescente.
 */
export const getAllTransactions = query({
  args: {},
  handler: async (ctx) => {
    const transactions = await ctx.db
      .query("transactions")
      .withIndex("by_date")
      .order("desc")
      .collect();
    return transactions;
  },
});

/**
 * Retorna transações de um mês específico (YYYY-MM).
 */
export const getTransactionsByMonth = query({
  args: { monthKey: v.string() }, // ex: "2026-05"
  handler: async (ctx, { monthKey }) => {
    const all = await ctx.db
      .query("transactions")
      .withIndex("by_date")
      .order("desc")
      .collect();

    return all.filter((t) => t.date.startsWith(monthKey));
  },
});

/**
 * Retorna os meses disponíveis (únicos), em ordem decrescente.
 */
export const getAvailableMonths = query({
  args: {},
  handler: async (ctx) => {
    const all = await ctx.db.query("transactions").collect();
    const months = [...new Set(all.map((t) => t.date.slice(0, 7)))];
    return months.sort().reverse();
  },
});

/**
 * Resumo financeiro geral.
 */
export const getSummary = query({
  args: {},
  handler: async (ctx) => {
    const all = await ctx.db.query("transactions").collect();

    const received = all.filter((t) => t.value > 0);
    const sent = all.filter((t) => t.value < 0);

    const totalReceived = received.reduce((acc, t) => acc + t.value, 0);
    const totalSent = Math.abs(sent.reduce((acc, t) => acc + t.value, 0));
    const netBalance = totalReceived - totalSent;

    // Contribuintes únicos (apenas entradas)
    const contributors = new Set(received.map((t) => t.name));

    return {
      totalReceived,
      totalSent,
      netBalance,
      contributorsCount: contributors.size,
      receivedCount: received.length,
      sentCount: sent.length,
      totalTransactions: all.length,
    };
  },
});

/**
 * Top 5 maiores contribuintes (por soma de entradas).
 */
export const getTopContributors = query({
  args: { limit: v.optional(v.number()) },
  handler: async (ctx, { limit = 5 }) => {
    const received = await ctx.db
      .query("transactions")
      .withIndex("by_detail", (q) => q.eq("detail", "Recebido"))
      .collect();

    const totals: Record<string, number> = {};
    for (const t of received) {
      totals[t.name] = (totals[t.name] || 0) + t.value;
    }

    return Object.entries(totals)
      .map(([name, total]) => ({ name, total }))
      .sort((a, b) => b.total - a.total)
      .slice(0, limit);
  },
});

/**
 * Dados para o gráfico de fluxo mensal.
 * Retorna array com { month, received, sent } por mês.
 */
export const getMonthlyFlow = query({
  args: { months: v.optional(v.number()) }, // 6, 12 ou undefined (todos)
  handler: async (ctx, { months }) => {
    const all = await ctx.db
      .query("transactions")
      .withIndex("by_date")
      .order("asc")
      .collect();

    const flowMap: Record<string, { received: number; sent: number }> = {};

    for (const t of all) {
      const key = t.date.slice(0, 7);
      if (!flowMap[key]) flowMap[key] = { received: 0, sent: 0 };
      if (t.value > 0) flowMap[key].received += t.value;
      else flowMap[key].sent += Math.abs(t.value);
    }

    let result = Object.entries(flowMap)
      .map(([month, data]) => ({ month, ...data }))
      .sort((a, b) => a.month.localeCompare(b.month));

    if (months) {
      result = result.slice(-months);
    }

    return result;
  },
});

/**
 * Distribuição de despesas por categoria (para gráfico de rosca).
 */
export const getExpensesByCategory = query({
  args: {},
  handler: async (ctx) => {
    const sent = await ctx.db
      .query("transactions")
      .withIndex("by_detail", (q) => q.eq("detail", "Enviado"))
      .collect();

    const categories: Record<string, number> = {
      "Segurança e Monitoramento": 0,
      "Emolumentos e Taxas": 0,
      "Outros": 0,
    };

    for (const t of sent) {
      const name = t.name.toLowerCase();
      const value = Math.abs(t.value);

      if (name.includes("segurança") || name.includes("monitor")) {
        categories["Segurança e Monitoramento"] += value;
      } else if (
        name.includes("instituição") ||
        name.includes("pagamento") ||
        name.includes("taxa") ||
        name.includes("emolumento")
      ) {
        categories["Emolumentos e Taxas"] += value;
      } else {
        categories["Outros"] += value;
      }
    }

    return Object.entries(categories)
      .filter(([, value]) => value > 0)
      .map(([label, value]) => ({ label, value }));
  },
});

/**
 * Histórico de contribuições de um associado específico (busca por nome).
 */
export const getAssociateHistory = query({
  args: { search: v.string() }, // nome ou prefixo do CPF
  handler: async (ctx, { search }) => {
    const term = search.toLowerCase().trim();

    const received = await ctx.db
      .query("transactions")
      .withIndex("by_detail", (q) => q.eq("detail", "Recebido"))
      .collect();

    const userTxs = received
      .filter((t) => t.name.toLowerCase().includes(term))
      .sort((a, b) => {
        const dateCompare = b.date.localeCompare(a.date);
        if (dateCompare !== 0) return dateCompare;
        return b.time.localeCompare(a.time);
      });

    if (userTxs.length === 0) return null;

    const total = userTxs.reduce((acc, t) => acc + t.value, 0);
    const months = new Set(userTxs.map((t) => t.date.slice(0, 7))).size;

    return {
      name: userTxs[0].name,
      total,
      monthsActive: months,
      lastDate: userTxs[0].date,
      transactions: userTxs,
    };
  },
});

/**
 * Retorna lista de inadimplentes: associados ativos sem pagamento no mês atual.
 */
export const getDefaulters = query({
  args: { monthKey: v.string() }, // ex: "2026-05"
  handler: async (ctx, { monthKey }) => {
    // Busca associados ativos
    const activeAssociates = await ctx.db
      .query("associates")
      .withIndex("by_status", (q) => q.eq("status", "ativo"))
      .collect();

    // Busca pagamentos do mês
    const monthTxs = await ctx.db
      .query("transactions")
      .withIndex("by_detail", (q) => q.eq("detail", "Recebido"))
      .collect();

    const paidThisMonth = new Set(
      monthTxs
        .filter((t) => t.date.startsWith(monthKey))
        .map((t) => t.name.toLowerCase())
    );

    // Encontra todos os pagamentos para calcular último pagamento
    const allReceived = await ctx.db
      .query("transactions")
      .withIndex("by_detail", (q) => q.eq("detail", "Recebido"))
      .collect();

    return activeAssociates
      .filter((a) => !paidThisMonth.has(a.name.toLowerCase()))
      .map((a) => {
        const lastPayment = allReceived
          .filter((t) => t.name.toLowerCase().includes(a.name.toLowerCase()))
          .sort((x, y) => y.date.localeCompare(x.date))[0];

        return {
          id: a._id,
          name: a.name,
          unit: a.unit,
          status: a.status,
          lastPaymentDate: lastPayment?.date ?? null,
        };
      })
      .sort((a, b) => a.unit.localeCompare(b.unit));
  },
});
