# Guia do Usuário - AMRTS Santorini

Este guia explica como operar o dashboard de contribuições e manter os dados atualizados.

## 1. Como atualizar os dados

O dashboard processa arquivos CSV exportados do InfinitePay.

### Carregamento automático

1. Exporte o novo extrato no InfinitePay.
2. Salve o arquivo `.csv` na pasta `extratos-infinite/`.
3. Em `script.js`, adicione o nome do arquivo na lista `csvFiles`:
   ```javascript
   const csvFiles = [
       'extratos-infinite/extrato.csv',
       'extratos-infinite/extrato_novo.csv'
   ];
   ```
4. Aguarde a sincronização do pCloud (se estiver usando o link público) e recarregue a página (**Ctrl+Shift+R**).

### Carregamento manual

Se nenhum arquivo for encontrado, aparece o botão **Carregar CSV Manualmente** no topo. Você pode selecionar um ou vários CSVs; o sistema une tudo e remove duplicatas.

## 2. Indicadores do painel

| Card | Significado |
|------|-------------|
| **Total Contribuições** | Soma das entradas (Pix recebidos dos associados) |
| **Despesas Pagas** | Soma das saídas (pagamentos e Pix enviados) |
| **Saldo em Caixa** | Contribuições menos despesas (recurso disponível) |
| **Associados** | Quantidade de pessoas que contribuíram no período |

## 3. Gráficos

- **Fluxo Mensal**: Evolução de contribuições e despesas por mês. Use o seletor para ver 6 meses, 12 meses ou todo o período.
- **Distribuição de Despesas**: Gráfico de rosca por categoria (segurança, emolumentos, outros).
- **Maiores Contribuintes**: Ranking dos cinco maiores valores recebidos.

## 4. Histórico de transações

### Paginação por mês

O histórico é organizado **um mês por vez**:

- **Mês anterior** / **Próximo mês**: Navega entre os meses (do mais recente para o mais antigo).
- **Seletor de mês**: Permite pular diretamente para um mês específico.
- O rodapé da tabela mostra, por exemplo: `Abril 2026 — 25 transações`.
- O indicador de período (ícone de calendário nos filtros) exibe o mês em visualização.

Todas as transações do mês selecionado aparecem na tabela (sem limite de linhas por página).

### Busca e filtros

- **Busca**: Filtra por nome ou tipo de transação em tempo real.
- **Tipo**: Todos, Recebidos ou Enviados.
- Ao buscar ou filtrar, a paginação permanece no mês atual quando possível; caso contrário, volta ao mês mais recente com resultados.

## 5. Exportação

O botão **Exportar** gera um CSV com as transações do **mês em exibição**, respeitando busca e filtro de tipo. Duplicatas já foram removidas na consolidação.

## 6. Área do Associado

Consulta individual para cada morador:

1. Clique em **Área do Associado** no menu superior.
2. Digite os 4 primeiros dígitos do CPF ou o nome completo.
3. O painel exibe total contribuído, meses ativos, última contribuição, gráfico e tabela resumida.

## 7. Personalização

- **Layout (Boxed / Wide)**: Visão centralizada (1440px) ou largura total.
- **Tema (Sol / Lua)**: Modo claro ou escuro.
- **Imprimir / PDF**: Versão otimizada para impressão (oculta menus e botões).

## 8. Dicas e problemas comuns

| Situação | O que fazer |
|----------|-------------|
| Página em "Carregando dados..." | Recarregue com **Ctrl+Shift+R**. Verifique se o pCloud sincronizou. |
| Dados zerados após atualizar código | Confirme que `script.js` carrega sem erro 404 no console do navegador (F12). |
| Mês com datas “estranhas” | Já corrigido no sistema: datas do CSV são exibidas sem conversão de fuso horário. |
| Alterações locais não aparecem online | Aguarde sincronização do pCloud; não é necessário upload manual ao filedn. |
