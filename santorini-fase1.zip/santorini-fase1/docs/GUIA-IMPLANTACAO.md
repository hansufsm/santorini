# Guia de Implantação — Fase 1
**AMRTS Santorini · GitHub Pages + Convex**

---

## PRÉ-REQUISITOS

Você precisará de:
- Conta GitHub: `github.com/zionsti` ✅
- Conta Convex: projeto `santorini` ✅
- Node.js instalado no desktop (para rodar o Convex)

---

## PASSO 1 — Criar o repositório no GitHub

1. Acesse `github.com/zionsti`
2. Clique em **"+"** → **"New repository"**
3. Preencha:
   - **Repository name:** `santorini`
   - Marque **Public**
   - **NÃO** marque "Add a README file" (vamos subir o nosso)
4. Clique **"Create repository"**

---

## PASSO 2 — Fazer upload dos arquivos

No repositório recém-criado, clique em **"uploading an existing file"** e faça upload de:

```
index.html          ← dashboard principal (arquivo existente, atualizar)
script.js           ← NOVO (versão 2.0 com Convex)
README.md           ← NOVO (atualizado)
.gitignore          ← NOVO
img/santorini.png
docs/index.html
docs/guia-usuario.md
docs/detalhes-tecnicos.md
```

**Estrutura de pastas a criar no GitHub:**
- Pasta `img/` → fazer upload de `santorini.png`
- Pasta `docs/` → fazer upload dos 3 arquivos
- Pasta `.github/workflows/` → fazer upload de `deploy.yml`
- Pasta `convex/` → fazer upload de `schema.ts`, `transactions.ts`, `associates.ts`

> Dica: No GitHub pelo navegador, você pode criar pastas digitando o nome da pasta + "/" antes do nome do arquivo no campo de nome.

---

## PASSO 3 — Ativar GitHub Pages

1. No repositório, vá em **Settings** → **Pages**
2. Em **Source**, selecione **"GitHub Actions"**
3. Salve

O GitHub Actions vai rodar automaticamente e publicar o site.  
URL: `https://zionsti.github.io/santorini`

---

## PASSO 4 — Configurar o Convex (no desktop)

```bash
# No terminal, na pasta do projeto clonado:
npx convex dev --configure=existing --team hans-rogerio-zimmermann --project santorini
```

O Convex vai:
1. Gerar a pasta `convex/_generated/`
2. Fazer deploy do schema e das funções
3. Exibir a **CONVEX_URL** (algo como `https://xxx.convex.cloud`)

---

## PASSO 5 — Atualizar a CONVEX_URL no script.js

Abra `script.js` e substitua na linha 12:

```javascript
// ANTES:
const CONVEX_URL = "https://SEU_PROJETO.convex.cloud";

// DEPOIS (use a URL real do seu projeto):
const CONVEX_URL = "https://xxx.convex.cloud";
```

Faça commit dessa alteração:
```bash
git add script.js
git commit -m "config: add Convex URL"
git push origin main
```

O GitHub Actions faz o deploy automaticamente. ✅

---

## PASSO 6 — Importar os dados existentes

1. Acesse `https://zionsti.github.io/santorini`
2. Clique em **"Importar CSV"**
3. Selecione o arquivo `extrato.csv`
4. Aguarde a confirmação: "X transações importadas"
5. O dashboard atualiza automaticamente com os dados

---

## PASSO 7 — Verificar funcionamento

Verifique no dashboard:
- [ ] Cards com valores corretos (Total Contribuições, Despesas, Saldo)
- [ ] Gráficos renderizando
- [ ] Histórico de transações por mês funcionando
- [ ] Área do Associado funcionando (busca por nome)
- [ ] Indicador "Convex · X transações" no rodapé

---

## FLUXO FUTURO (dia a dia)

```
Novo extrato InfinitePay
        ↓
Exportar CSV
        ↓
Acessar dashboard
        ↓
Clicar "Importar CSV"
        ↓
Dados atualizados no Convex ✅
```

---

## EDITAR O CÓDIGO

1. Edite aqui no Claude (me mande o arquivo atualizado)
2. Faça upload do arquivo no GitHub (substituindo o existente)
3. O GitHub Actions faz o deploy automático em ~1 minuto

---

*AMRTS Santorini © 2026*
