# Detalhes Técnicos - AMRTS Santorini

Documentação técnica sobre arquitetura, regras de negócio e manutenção do código.

## Arquitetura

SPA (Single Page Application) 100% no cliente:

| Tecnologia | Uso |
|------------|-----|
| **Tailwind CSS** (CDN) | Layout, tema e responsividade |
| **Chart.js** | Gráficos de linha, rosca e barras |
| **PapaParse** | Leitura e parse de CSV |
| **JavaScript ES6+** | Estado, filtros, deduplicação e UI |

### Arquivos principais

- `index.html` — estrutura, estilos, `<base>` dinâmico e ordem de carregamento dos scripts.
- `script.js` — estado global (`appState`), processamento, gráficos e eventos.
- `extratos-infinite/*.csv` — fonte de dados (formato InfinitePay).

### Estado global (`appState`)

```javascript
{
  rawTransactions: [],      // Todas as transações deduplicadas
  filteredTransactions: [], // Após busca e filtro de tipo
  summary: { ... },         // Totais dos cards
  pagination: {
    monthIndex: 0           // 0 = mês mais recente
  }
}
```

## Publicação e caminhos de arquivos

### pCloud + filedn

A pasta do projeto reside em `pCloudDrive/www/santorini`. O link público filedn.com expõe os mesmos arquivos após sync. Edições locais propagam automaticamente; não há pipeline de deploy separado.

### Tag `<base>` dinâmica

URLs como `.../santorini` (sem barra final) fazem o navegador resolver `script.js` na pasta pai, gerando **404**. Um script inline no `<head>` define:

```html
<base href="https://.../santorini/">
```

Assim, `script.js`, `extratos-infinite/extrato.csv` e `img/` resolvem corretamente.

### Ordem do DOM e `script.js`

O `script.js` deve ser o **último** elemento antes de `</body>`, depois do modal da Área do Associado. Se o script rodar antes de elementos como `#close-modal`, ocorre erro ao registrar listeners e o carregamento dos CSVs não inicia.

### Cache busting

O script é referenciado como `script.js?v=1.5` (incrementar após mudanças relevantes). Usuários devem usar recarregamento forçado (**Ctrl+Shift+R**) após atualizações.

### `resolveAsset()`

```javascript
const resolveAsset = (relativePath) => new URL(relativePath, document.baseURI).href;
```

Usado no `fetch` dos CSVs para garantir URL absoluta correta.

## Formato do CSV (InfinitePay)

Colunas esperadas:

| Coluna | Campo interno |
|--------|---------------|
| Data | `date` (YYYY-MM-DD) |
| Hora | `time` |
| Tipo de transação | `type` |
| Nome | `name` (prefixo "Pix " removido) |
| Detalhe | `detail` (Recebido / Enviado) |
| Valor | `value` (numérico via `parseValue`) |

## Deduplicação

Chave única (minúsculas):

```
data|hora|nome|valor|detalhe
```

Transações com a mesma chave em extratos diferentes são mantidas uma única vez (`Map`).

## Datas e fuso horário

**Problema evitado:** `new Date('2026-04-01')` interpreta UTC e, no Brasil, pode exibir **31/03/2026**.

**Solução:** funções sem conversão de fuso:

| Função | Descrição |
|--------|-----------|
| `parseDateParts(dateStr)` | Extrai dia, mês e ano de `YYYY-MM-DD` ou `DD/MM/YYYY` |
| `getMonthKey(dateStr)` | Retorna `YYYY-MM` para agrupamento e filtro |
| `formatDateBR(dateStr)` | Exibe `DD/MM/YYYY` na tabela |
| `toSortableTimestamp(date, time)` | Ordenação cronológica local |

A paginação por mês usa `getMonthKey`, não `startsWith` nem `new Date()` na exibição.

## Paginação do histórico

- Um **mês por “página”**; todas as linhas do mês são exibidas.
- `getAvailableMonths()` — meses únicos de `filteredTransactions`, ordem decrescente.
- `monthIndex` — índice na lista (0 = mais recente).
- **Mês anterior** incrementa o índice; **Próximo mês** decrementa.
- Seletor `#filter-month` sincronizado com `monthIndex` via `syncMonthSelect()`.

## Gráficos

### Fluxo mensal (`monthlyChart`)

- Agrupa por `getMonthKey(t.date)`.
- Datasets: **Contribuições** (entradas) e **Despesas** (saídas).
- Filtro de período: últimos 6/12 meses ou todo o histórico.

### Rosca de despesas (`expensesDonutChart`)

Categorização heurística por palavras-chave no nome:

- Segurança e monitoramento
- Emolumentos e taxas
- Outros / tarifas

Legenda à direita com percentuais; texto em **prata** (`#C0C0C0`) via `fontColor` em `generateLabels`.

### Maiores contribuintes (`topContributorsChart`)

Top 5 por soma de valores com `detail === 'Recebido'`.

## Área do Associado

1. Filtra `value > 0` e nome contendo o termo buscado.
2. Exibe métricas e gráfico de linha por mês.
3. Datas formatadas com `formatDateBR`.

## Eventos e inicialização

Listeners registrados com `bindOptional(id, event, handler)` para evitar erro se o elemento não existir.

Inicialização no `window.load`:

1. Itera `csvFiles` e faz `fetch` + `processData(data, true)`.
2. Se nenhum arquivo carregar, exibe upload manual.
3. `renderDashboard()` atualiza cards, gráficos e tabela.

## Performance

Processamento no browser. Para alguns milhares de linhas, `Map`/`Set` e uma única passagem sobre os dados mantêm resposta imediata.

## Manutenção — checklist

- [ ] Novo CSV: adicionar em `csvFiles` e em `extratos-infinite/`.
- [ ] Mudança em `script.js`: incrementar `?v=` em `index.html`.
- [ ] Novo elemento DOM usado no JS: manter **após** o HTML ou usar `bindOptional`.
- [ ] Testar URL pública **com e sem** barra final em `.../santorini`.
- [ ] Conferir console (F12): sem 404 em `script.js` ou CSV.

## Histórico de correções relevantes

| Data (aprox.) | Correção |
|---------------|----------|
| 2026-05 | `<base>` dinâmico e `script.js` ao final do body |
| 2026-05 | Paginação do histórico por mês (substitui páginas de 10 linhas) |
| 2026-05 | Datas sem fuso horário (`formatDateBR` / `getMonthKey`) |
| 2026-05 | Rótulo "Total Contribuições"; legenda da rosca em prata |
