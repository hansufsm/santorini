# AMRTS Santorini — Plano Técnico Fase 1
**Versão:** 1.0  
**Data:** Maio 2026  
**Responsável:** AMRTS Santorini  

---

## 1. Objetivo da Fase 1

Migrar o armazenamento de dados financeiros do sistema de arquivos CSV locais para o **Convex**, eliminando a dependência do pCloud para dados sensíveis, garantindo persistência em nuvem, tempo real e segurança.

---

## 2. Escopo da Fase 1

### Incluído
- Tabela `transactions` — todas as transações financeiras do InfinitePay
- Tabela `associates` — cadastro de associados vinculado às transações
- View calculada `defaulters` — inadimplentes gerada a partir das transações
- Script de importação CSV → Convex (upload único via dashboard)
- Dashboard lendo 100% do Convex (sem fallback CSV)

### Não incluído (Fases futuras)
- Documentos e atas
- Assembleias
- Comunicados
- Fornecedores
- Patrimônio e empréstimos
- Reserva de áreas comuns
- Manutenção preventiva
- Controle de acesso/visitantes
- Orçamento anual
- Banco de indicações

---

## 3. Stack Tecnológica

| Camada | Tecnologia |
|--------|-----------|
| Frontend | HTML5 + Tailwind CSS + Chart.js + PapaParse |
| Banco de dados | Convex (nuvem, tempo real) |
| Hospedagem | GitHub Pages |
| CI/CD | GitHub Actions (deploy automático) |
| Dados financeiros | InfinitePay (exportação CSV manual) |

---

## 4. Arquitetura da Fase 1

```
┌─────────────────────────────────────┐
│           GitHub Pages              │
│  index.html + script.js + docs/     │
└──────────────┬──────────────────────┘
               │ fetch (HTTPS)
               ▼
┌─────────────────────────────────────┐
│              Convex                  │
│  ┌───────────┐  ┌────────────────┐  │
│  │transactions│  │  associates   │  │
│  └───────────┘  └────────────────┘  │
│  ┌───────────────────────────────┐  │
│  │  defaulters (view calculada)  │  │
│  └───────────────────────────────┘  │
└─────────────────────────────────────┘
               ▲
               │ importCSV mutation
               │
┌─────────────────────────────────────┐
│  Administrador (você)               │
│  Upload CSV via dashboard           │
│  InfinitePay → extrato.csv          │
└─────────────────────────────────────┘
```

---

## 5. Schema do Convex

### 5.1 Tabela `transactions`

| Campo | Tipo | Descrição |
|-------|------|-----------|
| `_id` | Id | Gerado pelo Convex |
| `_creationTime` | number | Timestamp automático |
| `date` | string | Data no formato YYYY-MM-DD |
| `time` | string | Hora no formato HH:MM:SS |
| `type` | string | Tipo de transação (Pix, Boleto, etc.) |
| `name` | string | Nome limpo (sem prefixo "Pix ") |
| `detail` | string | "Recebido" ou "Enviado" |
| `value` | number | Valor numérico (positivo=entrada, negativo=saída) |
| `originalValue` | string | String original do CSV |
| `transactionKey` | string | Chave de deduplicação (único) |
| `importedAt` | number | Timestamp da importação |

**Índices:**
- `by_date` → ordenação cronológica
- `by_key` → deduplicação rápida
- `by_detail` → filtro Recebido/Enviado

### 5.2 Tabela `associates`

| Campo | Tipo | Descrição |
|-------|------|-----------|
| `_id` | Id | Gerado pelo Convex |
| `name` | string | Nome completo |
| `unit` | string | Número do lote/unidade |
| `cpf` | string | CPF (primeiros 4 dígitos para busca) |
| `phone` | string | Telefone de contato |
| `email` | string | E-mail |
| `status` | string | "ativo", "inativo", "inadimplente" |
| `joinedAt` | string | Data de adesão (YYYY-MM-DD) |
| `notes` | string | Observações |
| `createdAt` | number | Timestamp de criação |

**Índices:**
- `by_status` → filtro por situação
- `by_unit` → busca por lote

### 5.3 View `defaulters` (calculada)

Não é tabela física — é uma **query** que cruza `associates` com `transactions`:

- Busca associados com `status !== "inativo"`
- Verifica se há transação com `detail === "Recebido"` no mês corrente
- Retorna lista de inadimplentes com nome, unidade e último pagamento

---

## 6. Funções Convex (API)

### Mutations (escrita)
| Função | Descrição |
|--------|-----------|
| `importTransactions` | Recebe array de transações, deduplica e salva |
| `upsertAssociate` | Cria ou atualiza cadastro de associado |
| `updateAssociateStatus` | Atualiza status (ativo/inativo/inadimplente) |

### Queries (leitura)
| Função | Descrição |
|--------|-----------|
| `getAllTransactions` | Todas as transações ordenadas por data |
| `getTransactionsByMonth` | Transações de um mês específico |
| `getSummary` | Totais: contribuições, despesas, saldo, associados |
| `getTopContributors` | Top 5 maiores contribuintes |
| `getMonthlyFlow` | Dados para gráfico de fluxo mensal |
| `getExpensesByCategory` | Dados para gráfico de rosca |
| `getAssociateHistory` | Histórico de um associado específico |
| `getAllAssociates` | Lista todos os associados |
| `getDefaulters` | Lista inadimplentes do mês atual |

---

## 7. Fluxo de Importação CSV

```
1. Administrador exporta CSV do InfinitePay
2. Acessa o dashboard (GitHub Pages)
3. Clica em "Importar CSV"
4. Seleciona o arquivo .csv
5. PapaParse processa o arquivo no browser
6. Script chama mutation `importTransactions` no Convex
7. Convex deduplica por `transactionKey` e salva
8. Dashboard atualiza em tempo real (reatividade Convex)
```

**Chave de deduplicação:**
```
transactionKey = `${date}|${time}|${name}|${value}|${detail}`.toLowerCase()
```

---

## 8. Estrutura de Arquivos do Projeto

```
santorini/
├── index.html                  ← Dashboard principal (atualizado)
├── script.js                   ← Lógica + integração Convex (atualizado)
├── README.md                   ← Atualizado
├── .github/
│   └── workflows/
│       └── deploy.yml          ← GitHub Actions (novo)
├── convex/
│   ├── _generated/             ← Gerado automaticamente
│   ├── schema.ts               ← Schema das tabelas (novo)
│   ├── transactions.ts         ← Queries e mutations (novo)
│   ├── associates.ts           ← Queries e mutations (novo)
│   └── _utils.ts               ← Funções auxiliares (novo)
├── img/
│   └── santorini.png
└── docs/
    ├── index.html
    ├── guia-usuario.md
    └── detalhes-tecnicos.md
```

---

## 9. GitHub Actions — Deploy Automático

A cada `git push` na branch `main`:
1. GitHub Actions é acionado
2. Build do projeto (cópia dos arquivos estáticos)
3. Deploy automático no GitHub Pages
4. Site atualizado em ~1 minuto

**URL final:** `https://zionsti.github.io/santorini`

---

## 10. Variáveis de Ambiente

O Convex requer uma URL pública (`CONVEX_URL`) para conexão do frontend.

| Variável | Onde configurar | Exemplo |
|----------|----------------|---------|
| `CONVEX_URL` | `index.html` (inline) | `https://xxx.convex.cloud` |

> A `CONVEX_URL` é **pública** — não contém dados sensíveis, apenas o endereço do projeto.

---

## 11. Segurança

- CSVs com dados sensíveis **não são commitados** no GitHub (`.gitignore`)
- Dados ficam **exclusivamente no Convex** (criptografia em repouso)
- Acesso ao Convex Dashboard via login AMRTS
- Frontend público apenas lê dados — sem autenticação na Fase 1

> **Fase 2 prevê:** autenticação de administrador para importação e gestão.

---

## 12. Checklist de Implementação

### Convex
- [ ] Criar `convex/schema.ts`
- [ ] Criar `convex/transactions.ts`
- [ ] Criar `convex/associates.ts`
- [ ] Executar `npx convex dev` para gerar tipos
- [ ] Testar queries no Convex Dashboard

### Frontend
- [ ] Adicionar SDK Convex ao `index.html`
- [ ] Atualizar `script.js` para usar queries Convex
- [ ] Implementar botão "Importar CSV" com mutation
- [ ] Remover dependência de `extratos-infinite/extrato.csv`
- [ ] Testar deduplicação com importação dupla

### GitHub
- [ ] Criar repositório `santorini` (público)
- [ ] Configurar `.gitignore` (excluir CSVs)
- [ ] Criar `.github/workflows/deploy.yml`
- [ ] Push inicial de todos os arquivos
- [ ] Ativar GitHub Pages (branch `gh-pages`)
- [ ] Verificar URL pública funcionando

### Dados
- [ ] Importar `extrato.csv` existente via dashboard
- [ ] Verificar totais no dashboard pós-importação
- [ ] Confirmar deduplicação funcionando

---

## 13. Estimativa de Esforço

| Tarefa | Complexidade |
|--------|-------------|
| Schema Convex | Baixa |
| Queries e mutations | Média |
| Integração frontend | Média |
| GitHub Actions | Baixa |
| Testes e ajustes | Média |
| **Total estimado** | **~4-6 horas** |

---

*AMRTS Santorini — Documento interno. Fase 1 © 2026*
